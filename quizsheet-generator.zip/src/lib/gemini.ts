import { GoogleGenAI, Type } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({ apiKey: apiKey || "" });

export const generateQuiz = async (prompt: string, fileData?: { data: string; mimeType: string }) => {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `
Bạn là một chuyên gia soạn đề trắc nghiệm chuyên nghiệp cho hệ thống ngân hàng đề.
Nhiệm vụ của bạn là tạo ra các câu hỏi trắc nghiệm dựa trên yêu cầu hoặc tệp tin được cung cấp.
Sản phẩm đầu ra PHẢI là một Bảng Markdown (Markdown Table) duy nhất.

Cấu trúc và thứ tự các cột của bảng PHẢI tuân thủ nghiêm ngặt 10 cột:
Cột 1 (Mã câu hỏi): Định dạng CH-01, CH-02, ...
Cột 2 (Nội dung câu hỏi): Câu hỏi rõ ràng. Nếu là môn Toán, hãy sử dụng TeX (ví dụ: $x^2$). KHÔNG được chứa ký tự | bên trong nội dung.
Cột 3 (Phương án A / Ý a): Phương án 1 hoặc ý 1.
Cột 4 (Phương án B / Ý b): Phương án 2 hoặc ý 2.
Cột 5 (Phương án C / Ý c): Phương án 3 hoặc ý 3 (Để trống nếu là SHORT).
Cột 6 (Phương án D / Ý d): Phương án 4 hoặc ý 4 (Để trống nếu là SHORT).
Cột 7 (Đáp án đúng): 
    - Nếu là MCQ: Chỉ ghi A, B, C hoặc D.
    - Nếu là TRUE_FALSE: Ghi đáp án 4 ý cách nhau bằng dấu ; (Ví dụ: T;F;F;T). LƯU Ý: Dùng dấu CHẤM PHẨY (;) không dùng dấu gạch đứng (|).
    - Nếu là SHORT: Đáp án tối đa 4 kí tự.
Cột 8 (Loại câu hỏi): Điền chính xác: MCQ, TRUE_FALSE, hoặc SHORT.
Cột 9 (Lời giải chi tiết): Ngắn gọn, súc tích. KHÔNG được chứa ký tự | bên trong.
Cột 10 (Link ảnh): Để trống.

LƯU Ý QUAN TRỌNG:
1. KHÔNG viết bất kỳ văn bản nào ngoài bảng Markdown.
2. TUYỆT ĐỐI KHÔNG sử dụng ký tự | bên trong bất kỳ ô nào. Ký tự | CHỈ được dùng để phân tách các cột trong Markdown.
3. Đối với câu TRUE_FALSE: Đáp án cột 7 phải dùng dấu ; để ngăn cách (T;F;T;T). Hệ thống sẽ tự động chuyển sang dấu | sau.
4. Đảm bảo mỗi hàng có đúng 10 cột. Nếu thiếu dữ liệu hãy để trống ô đó nhưng vẫn phải có đủ các dấu | phân tách.
`;

  const contents: any[] = [{ text: prompt }];
  if (fileData) {
    contents.push({
      inlineData: {
        data: fileData.data,
        mimeType: fileData.mimeType,
      },
    });
  }

  const response = await ai.models.generateContent({
    model,
    contents: { parts: contents.map(c => typeof c === 'string' ? { text: c } : c) },
    config: {
      systemInstruction,
      temperature: 0.7,
    },
  });

  return response.text;
};
